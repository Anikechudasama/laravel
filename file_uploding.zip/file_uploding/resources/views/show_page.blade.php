
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    td,th{
        padding: 10px;
        border: 1px solid black;
    }
    #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #04AA6D;
        color: white;
    }</style>
<body>
    {{var_dump($mydata)}}
    <table id="customers" class="border">
        <tr>
            <th>id</th>
            <th>file</th>
        </tr>
   
   <tbody>
    @foreach ($mydata as $i )
    <tr>
        <td>{{$i['id']}}</th>
        <td><img src="storage/app/public/uploads/{{$i['file']}}" alt=""></th>
    </tr>    
    @endforeach
    

   </tbody>
    </table>    
</body>
</html>
