
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    td,th{
        padding: 10px;
        border: 1px solid black;
    }
    #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #04AA6D;
        color: white;
    }</style>
<body>
    <?php echo e(var_dump($mydata)); ?>

    <table id="customers" class="border">
        <tr>
            <th>id</th>
            <th>file</th>
        </tr>
   
   <tbody>
    <?php $__currentLoopData = $mydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($i['id']); ?></th>
        <td><img src="storage/app/public/uploads/<?php echo e($i['file']); ?>" alt=""></th>
    </tr>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

   </tbody>
    </table>    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\file_uploding\resources\views/show_page.blade.php ENDPATH**/ ?>