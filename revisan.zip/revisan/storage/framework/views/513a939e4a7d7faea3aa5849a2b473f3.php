<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
body {
  background: #005930;
}

.item-box{
    position: relative;
    overflow: hidden;
    display: block;
    background:#fff;
    /* max-width: 300px; */
    padding: 10px;
    border: 1px solid #eff2f1;
    box-shadow: #1d1e22 0 0 14px 2px;
    border-radius: 10px;
}
.product-item {
    text-align: center;
    text-decoration: none;
    display: block;
    position: relative;
    padding-bottom: 50px;
    cursor: pointer;
    z-index:2!important;
}
.product-item::before {
    bottom: 0;
    left: 0;
    right: 0;
    position: absolute;
    content: "";
    background: #0059307d;
    height: 0%;
    z-index: 0;
    border-radius: 10px;
    -moz-transition: .3s all ease;
    -webkit-transition: .3s all ease;
    -o-transition: .3s all ease;
    transition: .3s all ease;
}
.product-item figure {
    position: relative;
    margin-bottom: 40px;
}
.product-item figure::before {
    position: absolute;
    top: 0;
    left: -75%;
    z-index: 2;
    display: block;
    content: '';
    width: 50%;
    height: 100%;
    background: -webkit-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
    background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
    -webkit-transform: skewX(-25deg);
    transform: skewX(-25deg);
}
.product-item figure > img {
    padding: 0.8rem;
    transition: .3s all ease;
    -moz-transition: .3s all ease;
    -webkit-transition: .3s all ease;
    -o-transition: .3s all ease;
}
.product-item figure img {
    width: 100%;
}
.product-item h3 {
    color: #2f2f2f;
    text-decoration: none;
    z-index:2999 !important
}
.product-item strong {
    color: #2f2f2f;
    text-decoration: none;
}
.product-item .show-info{
  color:#888;
  z-index:9999;
}
.product-item .icon-cross {
    position: absolute;
    width: 35px;
    height: 35px;
    display: inline-block;
    background: #2f2f2f;
    bottom: 15px;
    left: 50%;
    -webkit-transform: translateX(-50%);
    -moz-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    -o-transform: translateX(-50%);
    transform: translateX(-50%);
    margin-bottom: 6px;
    border-radius: 50%;
    opacity: 0;
    visibility: hidden;
    -moz-transition: .3s all ease;
    -webkit-transition: .3s all ease;
    -o-transition: .3s all ease;
    transition: .3s all ease;
}

.product-item:hover::before {
    height: 70%;
  
}
.product-item:hover .product-title{
  /*color:#005930;*/
}
.product-item:hover figure::before{
  -webkit-animation: shine .75s;
  animation: shine .75s;
}
.product-item:hover .icon-cross {
    bottom: 0;
    opacity: 1;
    visibility: visible;
}

/*************************************
**** Product item style
**************************************/

/* Shine */
.product-item figure {
  position: relative;
  margin-bottom: 40px;
}
.product-item figure img{
  width:100%;
}
.product-item figure::before {
  position: absolute;
  top: 0;
  left: -75%;
  z-index: 2;
  display: block;
  content: '';
  width: 50%;
  height: 100%;
  background: -webkit-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
  background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
  -webkit-transform: skewX(-25deg);
  transform: skewX(-25deg);
}
figure:hover::before .product-item{
  border:10px solid red;
}
.product-item figure:hover::before {
  -webkit-animation: shine .75s;
  animation: shine .75s;
}
@-webkit-keyframes shine {
  100% {
    left: 100%;
  }
}
@keyframes shine {
  100% {
    left: 100%;
  }
}
</style>
<body>
    <div class="container">
        <div class="row">
          <div class="col-12 text-center mt-5" style="margin: auto;width: 200px; ">
              <div class="item-box  m-auto" style="width: 19rem;">
                  <a class="product-item" href="#">
                    <figure><img src="<?php echo e(asset('files/'.$t->file)); ?>"  class="img-fluid"></figure>
                    <h3 class="product-title"><?php echo e($t->name); ?></h3>
                    <div class="show-info"> 
                        <span><?php echo e($t->email); ?></span>
                        </div>
                    <strong class="product-price">
                            <bdi>
                                <span class="currencySymbol fw-light pe-1" style="font-size: 18px">id=</span><?php echo e($t->id); ?>

                            </bdi>
                        </strong>
      
                    <span class="icon-cross">
                      <img src="https://ustambaklava.000webhostapp.com/images/cross.svg" class="img-fluid">
                    </span>
                  </a>
                </div>
            </div>
          </div>
      </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\revisan\resources\views/viewdata.blade.php ENDPATH**/ ?>