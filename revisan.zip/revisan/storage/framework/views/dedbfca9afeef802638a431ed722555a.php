<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <h1>
      <?php if(session('message')): ?>
      <?php echo e(session('message')); ?>

        <?php endif; ?>
    </h1>
    <a href="<?php echo e(route('form.create')); ?>"> <button type="button" class="btn btn-primary">crate</button></a>
    <a href="<?php echo e(route('mail')); ?>"> <button type="button" class="btn btn-primary">send mail</button></a>
    <table class="table p-5 " style="margin: 10px">
        <thead>
          <tr>
            <th scope="col">id</th>
            <th scope="col">name</th>
            <th scope="col">email</th>
            <th scope="col">photo</th>
            <th scope="col">show</th>
            <th scope="col">edit</th>
            <th scope="col">delete</th>
          </tr>
        </thead>
        <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($t->id); ?></td>
    <td><?php echo e($t->name); ?></td>
    <td><?php echo e($t->email); ?></td>
    
    <td><img src="<?php echo e(asset('files/'.$t->file)); ?>" height="50px"></td>
    <td>
    <a href="<?php echo e(route('form.show',$t->id)); ?>"> <button type="button" class="btn btn-primary">show data</button></a>
    </td>
    <td>
      <a href="<?php echo e(route('form.edit',$t->id)); ?>"> <button type="button" class="btn btn-primary">edit</button></a>
      </td>
     
    <td>
      <form action="<?php echo e(route('form.destroy',$t->id)); ?>" method="post">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger">DELETE</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
      <td>no recode</td>
    </tr>
  <?php endif; ?>
          </tbody>
      </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

   
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\revisan\resources\views/table.blade.php ENDPATH**/ ?>