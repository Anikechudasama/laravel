<?php

namespace App\Http\Controllers;

use App\Http\Requests\myrequest;
use App\Models\form;
use Illuminate\Http\Request;
use App\Mail\sendmail;
use App\Mail\deletemail;
use App\Jobs\myJob;
use App\Jobs\myJob2;
use Illuminate\Support\Facades\Mail;

class form_contrller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = form::all();
        return view('table', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('form');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(myrequest $request)
    {


        $id =['id'=>$request['id']];
        $name = $request->input('name');
        $email = $request->input('email');
        $file = time() . '.' . $request->file('file')->extension();
        $data = [
            'name' => $name,
            'email' => $email,
            'file' => $file,
        ];
        $request->file('file')->move(public_path('files'), $file);
        form::updateOrCreate($id,$data);

        //   email send

        $storedata = [
            'titel' => 'https://meetanshi.com/',
            'body' => 'thanks you have  join this applicaition i weel support to nexte prosss',
            'name' => $name,
            'email' => $email,
            'file' => $file,
        ];
        // dispatch(new myjob($storedata,$storedata['email']))->delay(now()->addSeconds(30));
        Mail::to($email)->send(new sendmail($storedata));                                                
    return redirect('form')->with('message','data inserted successfully');
    }

    /**
     * Display the specified resource.
     */



    public function show(string $id)
    {
      $t= form::findOrFail($id);
return view('viewdata',compact('t'));
     }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $t= form::findOrFail($id);
        return view('form',compact('t'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $data = form::findOrFail($id);
        unlink(public_path('files/' . $data['file']));
        $data->delete();

        $deletedata = [
            'titel' => 'your data deletade successfully ',
            'body' => 'thanks you have  for log time use this applicaition good by',
            'name' => $data['name'],
            'email' => $data['email'],
            'file' => $data['file'],
        ];
        // dispatch(new myjob2($deletedata))->delay(now()->addSeconds(50));
        Mail::to($data['email'])->send(new sendmail($deletedata));
    return redirect('form')->with('message','data deleted successfully');

    }



    public function mail()
    {
        $data = form::all();
        foreach ($data as $d) {
            $storedata = [
                'titel' => 'your data inserted successfully enjoy yur application',
                'body' => 'thanks you have  join this applicaition i weel support to nexte prosss',
                'name' => $d['name'],
                'email' => $d['email'],
                'file' => $d['file'],
            ];
            Mail::to($d['email'])->send(new sendmail($storedata));
            // echo  $d['email'];
            // dispatch(new myjob($storedata))->delay(now()->addSeconds(30));
        }
    }
    public function myapi(){
        $data=form::all();
        return response()->json($data);
    }
}
