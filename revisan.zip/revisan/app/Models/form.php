<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class form extends Model
{
    use HasFactory;
    public $table = 'forms';
    public $fillable = ['name','email','file'];


public function setNameAttribute($value){
   $this->attributes['name'] = ucwords($value);
}


}
