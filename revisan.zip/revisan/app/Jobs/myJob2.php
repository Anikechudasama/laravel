<?php

namespace App\Jobs;

use App\Mail\deletemail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class myJob2 implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $deletedata;
    public function __construct($deletedata)
    {
        $this->deletedata = $deletedata;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        Mail::to('chudasamaaniket47@gmail.com')->send(new deletemail($this->deletedata));
    }
}
