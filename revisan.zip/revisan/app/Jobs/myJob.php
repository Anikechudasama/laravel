<?php

namespace App\Jobs;

USE App\Mail\sendmail;
use Illuminate\Support\Facades\Mail; 
use Illuminate\Bus\Queueable;
 use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class myJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

   protected $storedata;
   protected $email;
    public function __construct($storedata,$email)
    {
        $this->storedata = $storedata;
        $this->email = $email;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
       Mail::to($this->email)->send(new sendmail($this->storedata));
    }
}
