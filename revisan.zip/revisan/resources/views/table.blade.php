<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <h1>
      @if(session('message'))
      {{session('message')}}
        @endif
    </h1>
    <a href="{{route('form.create')}}"> <button type="button" class="btn btn-primary">crate</button></a>
    <a href="{{route('mail')}}"> <button type="button" class="btn btn-primary">send mail</button></a>
    <table class="table p-5 " style="margin: 10px">
        <thead>
          <tr>
            <th scope="col">id</th>
            <th scope="col">name</th>
            <th scope="col">email</th>
            <th scope="col">photo</th>
            <th scope="col">show</th>
            <th scope="col">edit</th>
            <th scope="col">delete</th>
          </tr>
        </thead>
        <tbody>
  @forelse ($data as $t)
  <tr>
    <td>{{$t->id}}</td>
    <td>{{$t->name}}</td>
    <td>{{$t->email}}</td>
    
    <td><img src="{{asset('files/'.$t->file)}}" height="50px"></td>
    <td>
    <a href="{{route('form.show',$t->id)}}"> <button type="button" class="btn btn-primary">show data</button></a>
    </td>
    <td>
      <a href="{{route('form.edit',$t->id)}}"> <button type="button" class="btn btn-primary">edit</button></a>
      </td>
     
    <td>
      <form action="{{route('form.destroy',$t->id)}}" method="post">
        @method('DELETE')
        @csrf
        <button type="submit" class="btn btn-danger">DELETE</button>
      </form>
    </td>
  </tr>
  @empty
    <tr>
      <td>no recode</td>
    </tr>
  @endforelse
          </tbody>
      </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

   
  </body>
</html>
