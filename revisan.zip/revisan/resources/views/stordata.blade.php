<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>{{$storedata['titel']}}</h1>
<h3><b>titel:</b>{{$storedata['body']}}</h3>
<h4><b>name:</b>{{$storedata['name']}}</h4>
<h4><b>email:</b>{{$storedata['email']}}</h4>
<p><b>photo:</b><img src="{{asset('files/'.$storedata['file'])}}" height="30px" alt=""></p>
</body>
</html>