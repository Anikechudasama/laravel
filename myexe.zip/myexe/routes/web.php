<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ex1_controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::resource('newpage', ex1_controller::class);

Route::get('/', function () {
    return view('welcome');
});

Route::get('get_url_peramiter/{id}', function (string $id) {
    return "<h1> post id=" . $id . "</h1>";
});

Route::prefix('page')->group(function () {
    Route::get('page1', function () {
        return view('page1');
    });
    Route::get('page2', function () {
        return view('page2');
    });
    Route::get('page3', function () {
        return view('page3');
    });
});
