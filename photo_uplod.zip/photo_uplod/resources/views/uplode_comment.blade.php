<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
            user-select: none;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            width: 100vw;
            background-color: #eee;
            padding: 10px;
        }

        select {
            width: 400px;
            max-width: 100%;
            overflow-y: auto;
            cursor: pointer;
            padding: 15px 25px;
            -webkit-appearance: none;
            -moz-appearance: none;
            border: none;
            outline: none;
            border-radius: 12px;
            color: #444;
            font-size: 18px;
            box-shadow: -3px 3px 5px 0px rgba(0, 0, 0, 0.10);
        }

        select option {
            padding: 10px 20px;
            margin-bottom: 8px;
            border-radius: 12px;
            background-color: rgb(238, 238, 238);
            white-space: pre-wrap;
            cursor: pointer;
        }

        select option:hover {
            background-color: rgb(223, 223, 223);
        }

        select option:checked {
            box-shadow: 0 0 10px 100px #595959 inset;
        }

        select::-webkit-scrollbar-track {
            background-color: #F5F5F5;
            border-radius: 12px;
        }

        select::-webkit-scrollbar {
            width: 8px;
            background-color: #F5F5F5;
        }

        select::-webkit-scrollbar-thumb {
            background-color: rgb(225, 225, 225);
            border-radius: 12px;
            background-image: -webkit-linear-gradient(90deg,
                    rgba(160, 160, 160, 0.2) 25%,
                    transparent 25%,
                    transparent 50%,
                    rgba(160, 160, 160, 0.2) 50%,
                    rgba(160, 160, 160, 0.2) 75%,
                    transparent 75%,
                    transparent)
        }

        select.fadeIn {
            animation: fadeInDown 0.2s;
        }

        select.fadeOut {
            animation: fadeInUp 0.2s;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <form action="{{route('commentUplode.store')}}" method="post">
        @csrf
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Comment</span>
            </div>
            <input type="text" class="form-control" name="comment" placeholder="Username" aria-label="Username"
                aria-describedby="basic-addon1">
        </div>
        <select size="1" name="post_id">
            <option value="">Select an Post</option>
            <option value="1">First option</option>

        </select>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
        </script>
        <script>
            let select = document.querySelector('select');

            select.addEventListener('focus', () => {
                select.size = 5;
                select.classList.add('fadeIn');
                select.classList.remove('fadeOut');
                select.style.backgroundColor = '#FFF';
            });

            select.addEventListener('blur', () => {
                select.size = 1;
                select.classList.add('fadeOut');
                select.classList.remove('fadeIn');
                select.style.backgroundColor = '#FFF';
            });

            select.addEventListener('change', () => {
                select.size = 1;
                select.blur();
                select.style.backgroundColor = '#FFF';
            });

            select.addEventListener('mouseover', () => {
                if (select.size == 1) {
                    select.style.backgroundColor = 'rgb(247, 247, 247)';
                }
            });
            select.addEventListener('mouseout', () => {
                if (select.size == 1) {
                    select.style.backgroundColor = '#FFF';
                }
            });
        </script>
</body>

</html>
