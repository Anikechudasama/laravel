<?php

namespace App\Http\Controllers;
use App\Models\student_login;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Http\Requests\student_request;

class studentns extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = student_login::get();

        return  view('deshboard',compact('data'));   
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
   
        return view('registration');   
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(student_request $request)
    {
    $post=$request->input();
     student_login::student_stor($post) ;
    return redirect('students');
}

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $data3= student_login::findOrFail($id)->toArray();
        return view('registration',compact('data3'));   
   
    }
    

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
     
        student_login::data_delet($id);
        return redirect('students');
    }

    public function login_page(Request $request ){
       
        // var_dump($post); 
        $email=$request->input('s_email');
        $pass=$request->input('s_password');
        $data=student_login::where('s_email',$email)->first();
        if($data && Hash::check($pass, $data->s_password)){
            return redirect('students')->with('message','login successfully');
        } 
        else{
            return redirect('login')->with('error','invelid email and password');

        }

     
    }
}
