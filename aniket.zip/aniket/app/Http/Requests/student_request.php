<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class student_request extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */

    public function rules(): array
    {

        $id=$this->input('id');

        if($id){
            $velid_email='required|email|';
        }
        else{
$velid_email='required|email|unique:student';
        }


        return [
            's_name'=>'required|string',
            's_email'=>$velid_email,
            's_password'=>'required|string',
        ];
    }
}
