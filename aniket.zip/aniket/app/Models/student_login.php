<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;

class student_login extends Model
{
    use HasFactory;

  public static  function  student_stor($data){
        var_dump($data);
        unset($data['_token']);
        $data['s_password']=Hash::make($data['s_password']);
        $id = ['id'=> $data['id']];
        student_login::updateOrCreate($id,$data);
    }

    
  public  static function data_delet($id){
    $data1= student_login::findOrFail($id);
    $data1->delete();

}

   
protected $table ='student';
protected $fillable =  ['s_name','s_email','s_password'];


}
