<?php
    
$collection = collect([
    'name' => 'taylor',
    'languages' => [
        'php', 'javascript'
    ]
]);
print_r($collection->all());
 

$flattened = $collection->flatten();
 
print_r($flattened->all());

?><?php /**PATH C:\xampp\htdocs\aniket\resources\views/exe.blade.php ENDPATH**/ ?>