<?php
use App\Http\Controllers\studentns;
use App\Models\ex;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::resource('students',studentns::class);
Route::post('login_page',[studentns::class,'login_page'])->name('login_page');


Route::get('login', function () {
    return view('login');
})->name('login');

Route::get('exe', function () {
    return view('exe');
})->name('exe');
