<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\coments;
use Illuminate\Database\Eloquent\SoftDeletes;

class post extends Model
{
    use HasFactory,SoftDeletes;
    protected  $table = 'posts';
    protected  $fillable = ['name'];

    public function get_coments(){
return $this->hasmany(coments::class); 
    }
}
