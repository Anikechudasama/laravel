<?php

namespace App\Http\Controllers;

use App\Models\coments;
use Illuminate\Http\Request;
use App\Models\post;

class post_controller extends Controller
{
    public function create()
    {
        return view('add_post');
    }


    public function insert(Request $request)
    {
        $data = $request->input();
        unset($data['_token']);
        post::create($data);
        return redirect('show_post');
    }

    public function show()
    {
        $new = post::with('get_coments')->get();
        return view('show_coments', compact('new'));
    }

    public function destroy(String $id)
    {
        $data = coments::findOrFail($id);
        $data->delete();
        return redirect()->back();
    }
}
