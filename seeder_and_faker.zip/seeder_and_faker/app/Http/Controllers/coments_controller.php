<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\coments;
use App\Models\post;
use PhpParser\Node\Expr\Cast\String_;

class coments_controller extends Controller
{
    public function create()
    {
        $data = post::get()->toArray();
        return view('add_coments', compact('data'));
    }


    public function insert(Request $request)
    {
        $data = $request->input();
        unset($data['_token']);
        coments::create($data);
        return redirect('show_coment');
    }

    public function show()
    {
        $new = coments::with('postDetails')->get();
        return view('show_post', compact('new'));
    }


    public function destroy(String $id)
    {
        $data=post::findOrFail($id);
        $data->get_coments()->delete();
        $data->delete();
        return redirect()->back();
        // return print_r($data);
    }
}
