<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use App\Models\myexe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Database\Eloquent\SoftDeletes;

class ex1_controller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = myexe::get()->toArray();
        return view('ex1',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $post=$request->input();
        unset($post['_token']);
        myexe::create($post);
//          $m_data=['massage'=>'data iserteade successfully'];
// return view('ex1',compact('m_data'));
        //  $mydata->delete();  //FOR A 1
        //  return   print_r($mydata);  
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }
  

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {


        $post= myexe::findOrFail($id);
         $post->delete();  
        //  $post->restore();  
     
        return redirect('ex1')->with('massage','data deleted successfully');
    }
    
}
