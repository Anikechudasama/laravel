<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>vomment demo</title>
    <style>
      form{
        width: 80%;
        margin: auto
      }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  </head>
  <body>
    <h1>add comment</h1>
    {{-- <pre>
      {{print_r($data)}}
    </pre> --}}
    <form action="{{route('insert_coment')}}" method="post">
        <div class="mb-3">
          @csrf
          <label for="exampleInputEmail1" class="form-label">enter your comment</label>
          <input type="name" name="name" class="form-control" id="name" aria-describedby="emailHelp">
        </div>
<select required name="post_id" id="post_id" class="form-select form-select-lg mb-3" aria-label="Large select example">
    <option value="" selected>select post id</option>
@foreach ($data as $d)
  
<option value="{{$d['id']}}">{{$d['name']}}</option>
@endforeach

  </select>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html>