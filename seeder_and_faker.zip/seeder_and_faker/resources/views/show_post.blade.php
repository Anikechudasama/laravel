<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>post demo</title>
    <style>
        form {
            width: 80%;
            margin: auto
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>

<body>
    <div>

    </div>
    <table style="width: 80%;margin: auto" class="table">
        <thead>
            <tr>
                <th scope="col">id</th>
                <th scope="col">coment</th>
                <th scope="col">post</th>
                <th scope="col">Opration</th>

            </tr>
        </thead>
        <tbody>

            @foreach ($new as $d)
                <tr>
                    <td>{{ $d['id'] }}</td>
                    <td>{{ $d['name'] }}</td>
                    <td>{{ $d['postDetails']['name'] }}</td>  
                    {{-- @php
                        $id=$d['postDetails']['id']; 
                    @endphp --}}
                    <form action="{{ route('destroy_post',$d['id'])}}" method="post">
                        @method('DELETE')
                        @csrf
                        <td> <button type="submit" class="btn btn-outline-danger">Delete</button>
                    </form>
                </tr>
            @endforeach

        </tbody>
    </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>
</body>

</html>
