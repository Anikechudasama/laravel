<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>post demo</title>
    <style>
        form {
            width: 80%;
            margin: auto
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>



<body>

    <div>
        <pre>
  


  </pre>

    </div>
    <table style="width: 80%;margin: auto" class="table">
        <thead>

            <tr>
                <th scope="col">post_name</th>
                <th scope="col">opration</th>
                <th scope="col">id</th>
                <th scope="col">coment_name</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($new as $d)
                @php
                    $count = count($d['get_coments']);
                @endphp
                <tr>
                    <td rowspan="{{ $count }}">

                        {{ $d['name'] }} </td>
                    <td rowspan="{{ $count }}">
                        <form action="{{ route('destroy_coment', $d['id']) }}" method="post">
                            @method('DELETE')
                            @csrf
                            <button type="submit" class="btn btn-outline-danger">Delete</button>
                        </form>
                    </td>
                    @foreach ($d['get_coments'] as $m)
                        <td>{{ $m['id'] }}</td>
                        <td>{{ $m['name'] }}</td>



                </tr>
            @endforeach
            @endforeach
        </tbody>
    </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>
</body>

</html>
