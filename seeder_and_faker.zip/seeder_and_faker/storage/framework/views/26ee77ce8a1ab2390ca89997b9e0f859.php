<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>vomment demo</title>
    <style>
      form{
        width: 80%;
        margin: auto
      }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  </head>
  <body>
    <h1>add comment</h1>
    <pre>
      <?php echo e(print_r($data)); ?>

    </pre>
    <form action="<?php echo e(route('insert_coment')); ?>" method="post">
        <div class="mb-3">
          <?php echo csrf_field(); ?>
          <label for="exampleInputEmail1" class="form-label">enter your comment</label>
          <input type="name" name="name" class="form-control" id="name" aria-describedby="emailHelp">
        </div>
<select required name="post_id" id="post_id" class="form-select form-select-lg mb-3" aria-label="Large select example">
    <option value="" selected>select post id</option>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
<option value="<?php echo e($d['id']); ?>"><?php echo e($d['name']); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </select>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\seeder_and_faker\resources\views/add_coments.blade.php ENDPATH**/ ?>