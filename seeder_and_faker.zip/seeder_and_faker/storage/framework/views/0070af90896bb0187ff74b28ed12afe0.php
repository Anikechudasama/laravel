<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>post demo</title>
    <style>
        form {
            width: 80%;
            margin: auto
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>

<body>
    <div>

    </div>
    <table style="width: 80%;margin: auto" class="table">
        <thead>
            <tr>
                <th scope="col">id</th>
                <th scope="col">coment</th>
                <th scope="col">post</th>
                <th scope="col">Opration</th>

            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d['id']); ?></td>
                    <td><?php echo e($d['name']); ?></td>
                    <td><?php echo e($d['postDetails']['name']); ?></td>  
                    
                    <form action="<?php echo e(route('destroy_post',$d['id'])); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <td> <button type="submit" class="btn btn-outline-danger">Delete</button>
                    </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\seeder_and_faker\resources\views/show_post.blade.php ENDPATH**/ ?>