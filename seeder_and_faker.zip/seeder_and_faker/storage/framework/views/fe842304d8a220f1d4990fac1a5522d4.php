<!DOCTYPE html>
<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <style>
        * {
            box-sizing: border-box;
        }

        input[type=text],
        select,
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        label {
            padding: 12px 12px 12px 0;
            display: inline-block;
        }

        input[type=submit] {
            background-color: #04AA6D;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        input[type=submit]:hover {
            background-color: #45a049;
        }

        .container {
            border-radius: 5px;
            background-color: #f2f2f2;
            padding: 20px;
        }

        .col-25 {
            float: left;
            width: 25%;
            margin-top: 6px;
        }

        .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
        }

        /* Clear floats after the columns */
        .row::after {
            content: "";
            display: table;
            clear: both;
        }

        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }

        /* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
        @media screen and (max-width: 600px) {

            .col-25,
            .col-75,
            input[type=submit] {
                width: 100%;
                margin-top: 0;
            }
        }

        .btn {
            background-color: red;
            color: white;
            font-weight: 900;
            padding: 5PX;
            margin: 0 auto;
        }
    </style>
</head>

<body>

    <div class="container">
        <?php if(session('massage')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('massage')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>


        <form id="Form" action="" method="POST">
            <div class="row">
                <?php echo csrf_field(); ?>
                <div class="col-25">
                    <label for="fname">First Name</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="first_name" placeholder="Your name..">
                </div>
            </div>
            <div class="row">
                <div class="col-25">
                    <label for="fname">last Name</label>
                </div>
                <div class="col-75">
                    <input type="text" id="lname" name="last_name" placeholder="Your name..">
                </div>
            </div>

            <div class="row">
                <div class="col-25">
                    <label for="fname">Email Name</label>
                </div>
                <div class="col-75">
                    <input type="text" id="Email" name="email" placeholder="Your name..">
                </div>
            </div>



            <input type="button" id='submit' value="Submit">

        </form>


    

    <table id="customers">
        <tr>
            <th>id</th>
            <th>Frist Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>softDelete</th>
           
        </tr>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d['id']); ?></td>
                <td><?php echo e($d['first_name']); ?></td>
                <td><?php echo e($d['last_name']); ?></td>
                <td><?php echo e($d['email']); ?></td>
             

                <td>
                    <form action="<?php echo e(route('ex1.destroy', $d['id'])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn  btn-delete">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>

    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
        crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {

            console.log('hii');

            $('#submit').click(function() {
                console.log('hjsdguyf');
                var myData = $('#Form').serialize()


                $.ajax({
                    url: "<?php echo e(route('ex1.store')); ?>",
                    method: 'post',
                    data: myData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(data) {
                        console.log(data);
                    }

                })

            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\seeder_and_faker\resources\views/ex1.blade.php ENDPATH**/ ?>