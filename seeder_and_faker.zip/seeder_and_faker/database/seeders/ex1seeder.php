<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\myexe;
use Faker\factory as feker;

class ex1seeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 1; $i <= 100; $i++) {
            $feker = feker::create();
            $myex = new myexe;
            $myex->first_name = $feker->name;
            $myex->last_name = $feker->name;
            $myex->email = $feker->email;
            $myex->save();
        }
    }
}
