<?php

use App\Http\Controllers\coments_controller;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ex1_controller;
use App\Http\Controllers\post_controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::resource('ex1', ex1_controller::class);

Route::get('/', function () {
    return view('welcome');
});

Route::get('get_url_peramiter/{id}', function (string $id) {
    return "<h1> post id=" . $id . "</h1>";
});

// soft delete
Route::get('mainpage', function () {
    return view('with_index');
});


Route::get('show_post',[post_controller::class,'show'])->name('show_post');
Route::get('show_coment',[coments_controller::class,'show'])->name('show_coment');
Route::get('post',[post_controller::class,'create'])->name('post_form');
Route::get('coment',[coments_controller::class,'create'])->name('coment_form');
Route::post('insert_post',[post_controller::class,'insert'])->name('insert_post');
Route::post('insrt_coment',[coments_controller::class,'insert'])->name('insert_coment');
Route::delete('destroy_post/{id}',[post_controller::class,'destroy'])->name('destroy_post');
Route::delete('destroy_coment/{id}',[coments_controller::class,'destroy'])->name('destroy_coment');



// route gruping
Route::prefix('page')->group(function () {
    Route::get('page1', function () {
        return view('page1');
    });
    Route::get('page2', function () {
        return view('page2');
    });
    Route::get('page3', function () {
        return view('page3');
    });
});
